document.querySelectorAll(".box, .box2").forEach((box, index) => {

});
